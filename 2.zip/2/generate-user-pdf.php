<?php
require_once('tcpdf/tcpdf.php'); // Adjust the path as needed
include('includes/db.php');

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$sql = "SELECT * FROM fish WHERE zivs LIKE '%$search%' OR apraksts LIKE '%$search%' OR suga LIKE '%$search%' ORDER BY ID ASC";
$result = $conn->query($sql);

// Create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Your Name');
$pdf->SetTitle('zivu informācija');
$pdf->SetSubject('zivu informācija');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// Set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 006', PDF_HEADER_STRING);

// Set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// Set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// Set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('dejavusans', '', 12); // Use DejaVuSans font

// Add a title
$pdf->Write(0, 'zivu informācija', '', 0, 'C', true, 0, false, false, 0);

// Fetch and display data
$html = '<table border="1" cellpadding="5">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>zivs</th>
                    <th>Apraksts</th>
                    <th>Suga</th>
                    <th>Maxlielums</th>
                    <th>Bilde</th>
                </tr>
            </thead>
            <tbody>';

while ($row = $result->fetch_assoc()) {
    $html .= '<tr>
                <td>' . $row['ID'] . '</td>
                <td>' . $row['zivs'] . '</td>
                <td>' . $row['apraksts'] . '</td>
                <td>' . $row['suga'] . '</td>
                <td>' . $row['maxlielums'] . '</td>
                <td><img src="' . $row['image'] . '" width="50" height="50"></td>
              </tr>';
}

$html .= '</tbody></table>';

// Output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// Close and output PDF document
$pdf->Output('zivu_informācija.pdf', 'D');

$conn->close();
?>
