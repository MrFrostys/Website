-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2024 at 09:01 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `latvija`
--

-- --------------------------------------------------------

--
-- Table structure for table `fish`
--

CREATE TABLE `fish` (
  `ID` int(11) NOT NULL,
  `zivs` varchar(255) NOT NULL,
  `apraksts` text NOT NULL,
  `suga` varchar(255) NOT NULL,
  `maxlielums` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fish`
--

INSERT INTO `fish` (`ID`, `zivs`, `apraksts`, `suga`, `maxlielums`, `image`) VALUES
(6, 'Varde', 'Abinieks, dzīvo slapjās vietās pie ūdeņiem.', 'Parastā varde', 13, 'uploads/parasta.png'),
(7, 'Salamandra', 'Rudeņos atstāj ūdeni un pārziemo alā vai zem akmeņiem.', 'Uguns salamandra', 12, 'uploads/Fire_salamander_Germany_10_2014.jpg'),
(8, 'Līdaka', 'Dzeltenzaļa ar tumšiem olīvzaļiem, pat melniem svītrojumiem uz muguras un sāniem. Mutē asi zobi, ķer citas zivis.', 'Baltijas lasis', 22, 'uploads/220px-PetitSaumon.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `email`, `password`, `is_admin`) VALUES
(1, 'aha@aha.aha', '$2y$10$P9s7uKZU8XRuz9.MkQg1KOsag2yWdBT/XOF/VBk4gph4RgyEAuxne', 1),
(2, 'afa@afa.afa', '$2y$10$mXwfz7W9/IIHKcKVsa93TuL/KMWhKAWzIP5FAb8ioX2qWqQJeA/XK', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fish`
--
ALTER TABLE `fish`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fish`
--
ALTER TABLE `fish`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
