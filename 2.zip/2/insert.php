<?php
include('includes/db.php');
session_start();

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dzīvnieks = $_POST['dzīvnieks'];
    $apraksts = $_POST['apraksts'];
    $suga = $_POST['suga'];
    $max_height = $_POST['max_height'];

    if ($_FILES['image']['name']) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
        $image = $target_file;
    } else {
        $image = "default.jpg";
    }

    $sql = "INSERT INTO animals (dzīvnieks, apraksts, suga, max_height, image) VALUES ('$dzīvnieks', '$apraksts', '$suga', '$max_height', '$image')";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <form action="insert.php" method="POST" enctype="multipart/form-data">
        <h2>Ievadīt jaunu dzīvnieku</h2>
        <label for="dzīvnieks">Dzīvnieks:</label>
        <input type="text" name="dzīvnieks" required>
        <label for="apraksts">Apraksts:</label>
        <input type="text" name="apraksts" required>
        <label for="suga">Suga:</label>
        <input type="text" name="suga" required>
        <label for="max_height">Max Height:</label>
        <input type="number" name="max_height" required>
        <label for="image">Bilde:</label>
        <input type="file" name="image" accept="image/*">
        <button type="submit">Ievadīt</button>
    </form>
</body>
</html>
