<?php
include('includes/db.php');
session_start();

$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;

$sort_column = isset($_GET['sort']) ? $_GET['sort'] : 'ID';
$sort_order = isset($_GET['order']) ? $_GET['order'] : 'ASC';
$sort_order_next = $sort_order === 'ASC' ? 'DESC' : 'ASC';

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$sql = "SELECT * FROM fish WHERE zivs LIKE '%$search%' OR apraksts LIKE '%$search%' ORDER BY $sort_column $sort_order";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Zivis</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
            background-color: #3e94ec;
            font-family: "Roboto", helvetica, arial, sans-serif;
            font-size: 16px;
            font-weight: 400;
            text-rendering: optimizeLegibility;
        }

        div.table-title {
            display: block;
            margin: auto;
            max-width: 600px;
            padding: 5px;
            width: 100%;
        }

        .table-title h3 {
            color: #fafafa;
            font-size: 30px;
            font-weight: 400;
            font-style: normal;
            font-family: "Roboto", helvetica, arial, sans-serif;
            text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);
            text-transform: uppercase;
        }

        .table-fill {
            background: white;
            border-radius: 3px;
            border-collapse: collapse;
            height: 320px;
            margin: auto;
            max-width: 600px;
            padding: 5px;
            width: 100%;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            animation: float 5s infinite;
        }

        th {
            color: #D5DDE5;
            background: #1b1e24;
            border-bottom: 4px solid #9ea7af;
            border-right: 1px solid #343a45;
            font-size: 23px;
            font-weight: 100;
            padding: 24px;
            text-align: left;
            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
            vertical-align: middle;
        }

        th:first-child {
            border-top-left-radius: 3px;
        }

        th:last-child {
            border-top-right-radius: 3px;
            border-right: none;
        }

        tr {
            border-top: 1px solid #C1C3D1;
            border-bottom: 1px solid #C1C3D1;
            color: #666B85;
            font-size: 16px;
            font-weight: normal;
            text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);
        }

        tr:hover td {
            background: #4E5066;
            color: #FFFFFF;
            border-top: 1px solid #22262e;
        }

        tr:first-child {
            border-top: none;
        }

        tr:last-child {
            border-bottom: none;
        }

        tr:nth-child(odd) td {
            background: #EBEBEB;
        }

        tr:nth-child(odd):hover td {
            background: #4E5066;
        }

        tr:last-child td:first-child {
            border-bottom-left-radius: 3px;
        }

        tr:last-child td:last-child {
            border-bottom-right-radius: 3px;
        }

        td {
            background: #FFFFFF;
            padding: 20px;
            text-align: left;
            vertical-align: middle;
            font-weight: 300;
            font-size: 18px;
            text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);
            border-right: 1px solid #C1C3D1;
        }

        td:last-child {
            border-right: 0px;
        }

        th.text-left {
            text-align: left;
        }

        th.text-center {
            text-align: center;
        }

        th.text-right {
            text-align: right;
        }

        td.text-left {
            text-align: left;
        }

        td.text-center {
            text-align: center;
        }
        td.text-right {
        text-align: right;
    }

    .navbar-inverse {
        background-color: #333;
        border-color: #080808;
    }

    .navbar-inverse .navbar-brand {
        color: #9d9d9d;
    }

    .navbar-inverse .navbar-brand:hover,
    .navbar-inverse .navbar-brand:focus {
        color: #ffffff;
    }

    .navbar-inverse .navbar-nav > li > a {
        color: #9d9d9d;
    }

    .navbar-inverse .navbar-nav > li > a:hover,
    .navbar-inverse .navbar-nav > li > a:focus {
        color: #ffffff;
        background-color: transparent;
    }

    .navbar-inverse .navbar-nav > .active > a,
    .navbar-inverse .navbar-nav > .active > a:hover,
    .navbar-inverse .navbar-nav > .active > a:focus {
        color: #ffffff;
        background-color: #080808;
    }

    .navbar-inverse .navbar-toggle {
        border-color: #080808;
    }

    .navbar-inverse .navbar-toggle:hover,
    .navbar-inverse .navbar-toggle:focus {
        background-color: #080808;
    }

    .navbar-inverse .navbar-toggle .icon-bar {
        background-color: #9d9d9d;
    }

    .navbar-inverse .navbar-collapse,
    .navbar-inverse .navbar-form {
        border-color: #080808;
    }

    .navbar-inverse .navbar-link {
        color: #9d9d9d;
    }

    .navbar-inverse .navbar-link:hover {
        color: #ffffff;
    }

    .navbar-inverse .navbar-nav > .dropdown > a:hover .caret {
        border-top-color: #ffffff;
        border-bottom-color: #ffffff;
    }

    .navbar-inverse .navbar-nav > .dropdown > a .caret {
        border-top-color: #9d9d9d;
        border-bottom-color: #9d9d9d;
    }

    .navbar-inverse .navbar-nav > .open > a,
    .navbar-inverse .navbar-nav > .open > a:hover,
    .navbar-inverse .navbar    -nav > .open > a:focus {
        background-color: #080808;
        color: #ffffff;
    }

    .navbar-inverse .navbar-nav > .open > a .caret,
    .navbar-inverse .navbar-nav > .open > a:hover .caret,
    .navbar-inverse .navbar-nav > .open > a:focus .caret {
        border-top-color: #ffffff;
        border-bottom-color: #ffffff;
    }

    .navbar-inverse .navbar-nav > .dropdown > a .caret {
        border-top-color: #9d9d9d;
        border-bottom-color: #9d9d9d;
    }

    .navbar-inverse .navbar-brand .glyphicon,
    .navbar-inverse .navbar-brand .fa {
        color: #9d9d9d;
    }

    @media (min-width: 768px) {
        .navbar-inverse {
            border-radius: 0;
        }
    }

    .navbar-inverse .navbar-nav > li > a {
        padding-top: 15px;
        padding-bottom: 15px;
    }

    .navbar-inverse .navbar-text {
        color: #9d9d9d;
    }

    .navbar-inverse .navbar-nav > li > a.logout-btn {
        color: #ffffff !important;
        border-left: 1px solid #080808;
    }

    .navbar-inverse .navbar-nav > li > a.logout-btn:hover {
        background-color: #080808;
    }
</style>
</head>
<body>
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">Zivis</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <form class="navbar-form navbar-right" role="search" action="" method="GET">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Search" name="search" value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <button type="submit" class="btn btn-default">Submit</button>
            </form>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="generate-user-pdf.php?search=<?php echo htmlspecialchars($search); ?>">Lejupielādēt PDF</a> </li>
                <li><a href="chart.php">View Chart</a></li>
                <li><a href="logout.php" class="logout-btn">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
<div id="average-maxlielums"></div>

<table class="table table-fill">
    <thead>
    <tr>
        <th class="text-left"><?php echo htmlspecialchars($search); ?>Zivs</th>
        <th class="text-left">Suga</th>
        <th class="text-left"><?php echo htmlspecialchars($search); ?>Apraksts</th>
        <th class="text-left"><a href="?sort=maxlielums&order=<?php echo $sort_order_next; ?>&search=<?php echo htmlspecialchars($search); ?>">Max Lielums</a></th>
        <th class="text-left">Bilde</th>
        <?php if ($is_admin): ?>
            <th class="text-left">Darbības</th>
        <?php endif; ?>
    </tr>
    </thead>
    <tbody class="table-hover">
    <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td class="text-left"><?php echo $row['zivs']; ?></td>
            <td class="text-left"><?php echo $row['suga']; ?></td>
            <td class="text-left"><?php echo $row['apraksts']; ?></td>
            <td class="text-left"><?php echo $row['maxlielums']; ?></td>
            <td class="text-left"><img src="<?php echo $row['image']; ?>" alt="Zivs bilde" style="max-width: 100px;"></td>
            <?php if ($is_admin): ?>
                <td class="text-left">
                    <a href="edit.php?id=<?php echo $row['ID']; ?>">Rediģēt</a>
                    <a href="delete.php?id=<?php echo $row['ID']; ?>" onclick="return confirm('Pārliecināts?')">Dzēst</a>
                </td>
            <?php endif; ?>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var checkboxes = document.querySelectorAll('.tree-checkbox');
        checkboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', function() {
                var totalMaxLielums = 0;
                var selectedCount = 0;
                checkboxes.forEach(function(checkbox) {
                    if (checkbox.checked) {
                        totalMaxLielums += parseInt(checkbox.dataset.maxlielums);
                        selectedCount++;
                    }
                });
                if (selectedCount > 0) {
                    var averageMaxLielums = totalMaxLielums / selectedCount;
                    document.getElementById('average-maxlielums').innerText = "Vidējais maksimālais lielums izvēlētajiem zivīm: " + averageMaxLielums.toFixed(2);
                } else {
                    document.getElementById('average-maxlielums').innerText = "";
                }
            });
        });
    });

   
</script>
</body>
</html>

