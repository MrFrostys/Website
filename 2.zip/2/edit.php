<?php
include('includes/db.php');
session_start();

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM fish WHERE ID = $id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $zivs = $_POST['zivs'];
    $apraksts = $_POST['apraksts'];
    $suga = $_POST['suga'];
    $maxlielums = $_POST['maxlielums'];

    if ($_FILES['image']['name']) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
        $image = $target_file;
    } else {
        $image = $row['image'];
    }

    $sql = "UPDATE fish SET zivs='$zivs', apraksts='$apraksts', suga='$suga', maxlielums='$maxlielums', image='$image' WHERE ID=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit zivi</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            font-family: 'Jost', sans-serif;
            background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
        }

        .main {
            width: 350px;
            height: auto;
            background: purple;
            overflow: hidden;
            border-radius: 10px;
            box-shadow: 5px 20px 50px #000;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        label {
            color: #fff;
            font-size: 1em;
            margin: 10px;
        }

        input {
            width: 100%;
            margin: 10px 0;
            padding: 8px;
            border: none;
            border-radius: 5px;
            outline: none;
        }

        button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            background-color: #573b8a;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            outline: none;
        }

        button:hover {
            background-color: #6d44b8;
        }

        button.goBack {
            background-color: #ccc;
            color: #000;
        }
    </style>
</head>
<body>
<div class="main">
    <form action="edit.php" method="POST" enctype="multipart/form-data" class="main">
        <h2>Edit zivi</h2>
        <input type="hidden" name="id" value="<?php echo $row['ID']; ?>">
        <label for="zivs">Zive:</label>
        <input type="text" name="zivs" value="<?php echo $row['zivs']; ?>" required>
        <label for="apraksts">Apraksts:</label>
        <input type="text" name="apraksts" value="<?php echo $row['apraksts']; ?>" required>
        <label for="suga">Suga:</label>
        <input type="text" name="suga" value="<?php echo $row['suga']; ?>" required>
        <label for="maxlielums">Maxlielums:</label> <!-- New field for max height -->
        <input type="number" name="maxlielums" value="<?php echo $row['maxlielums']; ?>" required>
        <label for="image">Bilde:</label>
        <input type="file" name="image" accept="image/*" required>
        <button type="submit">Atjaunināt</button>
    </form>
    
        <button class="goBack" onclick="window.location.href = 'index.php';">Go Back to Index</button>
    </div>
</body>
</html>

<?php
$conn->close();
?>

