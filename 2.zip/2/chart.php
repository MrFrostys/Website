<?php
include('includes/db.php');

$chart_sql = "SELECT zivs, maxlielums FROM fish";
$chart_data = $conn->query($chart_sql);

$animals = [];
$heights = [];

while ($row = $chart_data->fetch_assoc()) {
    $animals[] = $row['zivs'];
    $heights[] = $row['maxlielums'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chart</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f0f0;
        }
        canvas {
            width: 600px; /* Adjust the width as needed */
            height: 400px; /* Adjust the height as needed */
            margin: auto; /* Center the canvas horizontally */
            display: block;
        }
    </style>
</head>
<body>
    
    <canvas id="myChart"></canvas>
    
    <script>
        var animals = <?php echo json_encode($animals); ?>;
        var heights = <?php echo json_encode($heights); ?>;
        
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: animals,
                datasets: [{
                    label: 'Max Height',
                    data: heights,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: false, // Disable responsiveness
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                title: {
                    display: true,
                    text: 'Animal Max Heights'
                }
            }
        });
    </script>
    <button onclick="window.location.href = 'index.php';">Go Back to Index</button>
</body>
</html>


